// This is so that server and client can use the same port without
// inlining it, and so that only this place needs to be changed if we
// decide/need to use another port.

public class Port {
  public static final int number = 4484;
}
